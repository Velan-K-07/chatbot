from datetime import datetime
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False


def build_reply(message: str) -> str:
    text = (message or "").strip().lower()

    if not text:
        return "Please describe your symptoms or concern so I can help."

    emergency_terms = [
        "chest pain",
        "trouble breathing",
        "shortness of breath",
        "severe allergic",
        "anaphylaxis",
        "faint",
        "unconscious",
        "stroke",
        "seizure",
        "bleeding heavily",
        "suicidal",
        "thoughts of hurting myself",
    ]
    if any(term in text for term in emergency_terms):
        return (
            "This sounds urgent. Please seek emergency care immediately or contact local emergency services now. "
            "If you are in immediate danger, call emergency services right away."
        )

    if any(term in text for term in ["fever", "flu", "cold", "cough", "sore throat"]):
        return (
            "For common cold or flu-like symptoms, rest, drink fluids, and consider acetaminophen or ibuprofen if it is safe for you. "
            "Seek medical care if your fever is very high, symptoms last more than a few days, or you have trouble breathing."
        )

    if any(term in text for term in ["headache", "migraine"]):
        return (
            "For a mild headache, rest in a quiet room, drink water, and avoid screens. "
            "Seek care urgently if the headache is sudden, severe, or comes with weakness, confusion, or vision changes."
        )

    if any(term in text for term in ["stomach", "nausea", "vomit", "diarrhea", "indigestion"]):
        return (
            "Try small sips of water, oral rehydration salts, and bland foods such as rice or toast. "
            "Seek care if there is blood in your stool, persistent vomiting, or signs of dehydration."
        )

    if any(term in text for term in ["allergy", "rash", "itching", "hives"]):
        return (
            "Avoid the trigger, keep the skin cool, and use a gentle moisturizer. "
            "Seek urgent care if you develop facial swelling, throat tightness, or trouble breathing."
        )

    if any(term in text for term in ["anxiety", "stress", "panic", "sleep"]):
        return (
            "Try slow breathing, a short walk, and a calm environment. "
            "If your anxiety feels overwhelming or you feel unsafe, contact a mental health professional or emergency help right away."
        )

    if any(term in text for term in ["pain", "injury"]):
        return (
            "Rest the affected area and apply ice if appropriate. "
            "Seek professional care if the pain is severe, you have numbness, or you cannot move the area."
        )

    return (
        "Thanks for sharing that. I can offer general wellness guidance for non-emergency symptoms. "
        "Please tell me more about the concern and how long it has been going on."
    )


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()

    if not message:
        return jsonify({"reply": "Please describe your symptoms or concern."}), 400

    reply = build_reply(message)
    return jsonify({"reply": reply, "timestamp": datetime.utcnow().isoformat() + "Z"})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
